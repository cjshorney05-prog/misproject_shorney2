// Flappy Bird Game JavaScript
class FlappyBirdGame {
    constructor() {
        this.gameArea = document.getElementById('game-area');
        this.bird = document.getElementById('bird');
        this.pipes = document.getElementById('pipes');
        this.ground = document.getElementById('ground');
        this.scoreDisplay = document.getElementById('score');
        this.highScoreDisplay = document.getElementById('high-score');
        this.startScreen = document.getElementById('start-screen');
        this.gameOverScreen = document.getElementById('game-over-screen');
        this.finalScoreDisplay = document.getElementById('final-score');
        this.finalHighScoreDisplay = document.getElementById('final-high-score');
        
        this.gameStarted = false;
        this.gameOver = false;
        this.score = 0;
        this.highScore = localStorage.getItem('flappyBirdHighScore') || 0;
        this.birdY = 250;
        this.birdVelocity = 0;
        this.gravity = 0.5;
        this.jumpPower = -8;
        this.pipeSpeed = 2;
        this.pipeGap = 150;
        this.pipeWidth = 60;
        this.pipesArray = [];
        this.gameLoop = null;
        this.pipeSpawnTimer = 0;
        this.pipeSpawnInterval = 1800; // milliseconds
        
        this.init();
    }
    
    init() {
        this.setupEventListeners();
        this.updateHighScore();
        this.resetBirdPosition();
    }
    
    setupEventListeners() {
        // Start game button
        document.getElementById('start-btn').addEventListener('click', () => this.startGame());
        
        // Restart game button
        document.getElementById('restart-btn').addEventListener('click', () => this.restartGame());
        
        // Keyboard controls
        document.addEventListener('keydown', (e) => {
            if (e.code === 'Space') {
                e.preventDefault();
                if (!this.gameStarted) {
                    this.startGame();
                } else if (!this.gameOver) {
                    this.flap();
                } else {
                    this.restartGame();
                }
            }
        });
        
        // Mouse/touch controls
        this.gameArea.addEventListener('click', () => {
            if (!this.gameStarted) {
                this.startGame();
            } else if (!this.gameOver) {
                this.flap();
            } else {
                this.restartGame();
            }
        });
        
        // Prevent context menu on right click
        this.gameArea.addEventListener('contextmenu', (e) => e.preventDefault());
    }
    
    startGame() {
        this.gameStarted = true;
        this.gameOver = false;
        this.score = 0;
        this.birdY = 250;
        this.birdVelocity = 0;
        this.pipesArray = [];
        this.pipeSpawnTimer = 0;
        
        // Hide start screen
        this.startScreen.style.display = 'none';
        
        // Clear existing pipes
        this.pipes.innerHTML = '';
        
        // Reset bird position
        this.resetBirdPosition();
        
        // Start game loop
        this.gameLoop = setInterval(() => this.update(), 16); // ~60 FPS
        
        // Update display
        this.updateScore();
    }
    
    restartGame() {
        this.gameOverScreen.style.display = 'none';
        this.startGame();
    }
    
    flap() {
        if (this.gameStarted && !this.gameOver) {
            this.birdVelocity = this.jumpPower;
            this.bird.classList.add('flap');
            
            // Remove flap class after animation
            setTimeout(() => {
                this.bird.classList.remove('flap');
            }, 150);
        }
    }
    
    update() {
        if (!this.gameStarted || this.gameOver) return;
        
        // Update bird physics
        this.birdVelocity += this.gravity;
        this.birdY += this.birdVelocity;
        
        // Update bird position
        this.bird.style.top = this.birdY + 'px';
        
        // Spawn pipes
        this.pipeSpawnTimer += 16;
        if (this.pipeSpawnTimer >= this.pipeSpawnInterval) {
            this.spawnPipe();
            this.pipeSpawnTimer = 0;
        }
        
        // Update pipes
        this.updatePipes();
        
        // Check collisions
        this.checkCollisions();
        
        // Check if bird hit ground
        if (this.birdY + 30 >= this.gameArea.offsetHeight - 80) {
            this.gameOver = true;
            this.endGame();
        }
    }
    
    spawnPipe() {
        const gameHeight = this.gameArea.offsetHeight;
        const groundHeight = 80;
        const availableHeight = gameHeight - groundHeight;
        const minHeight = 50;
        const maxHeight = availableHeight - this.pipeGap - minHeight;
        
        const topHeight = Math.random() * (maxHeight - minHeight) + minHeight;
        const bottomHeight = availableHeight - topHeight - this.pipeGap;
        
        // Create top pipe
        const topPipe = document.createElement('div');
        topPipe.className = 'pipe top';
        topPipe.style.height = topHeight + 'px';
        topPipe.style.left = this.gameArea.offsetWidth + 'px';
        topPipe.dataset.passed = 'false';
        
        // Create bottom pipe
        const bottomPipe = document.createElement('div');
        bottomPipe.className = 'pipe bottom';
        bottomPipe.style.height = bottomHeight + 'px';
        bottomPipe.style.left = this.gameArea.offsetWidth + 'px';
        bottomPipe.dataset.passed = 'false';
        
        this.pipes.appendChild(topPipe);
        this.pipes.appendChild(bottomPipe);
        
        this.pipesArray.push({
            top: topPipe,
            bottom: bottomPipe,
            x: this.gameArea.offsetWidth,
            passed: false
        });
    }
    
    updatePipes() {
        for (let i = this.pipesArray.length - 1; i >= 0; i--) {
            const pipe = this.pipesArray[i];
            pipe.x -= this.pipeSpeed;
            
            pipe.top.style.left = pipe.x + 'px';
            pipe.bottom.style.left = pipe.x + 'px';
            
            // Check if pipe passed bird (for scoring)
            if (!pipe.passed && pipe.x + this.pipeWidth < 80) {
                pipe.passed = true;
                this.score++;
                this.updateScore();
            }
            
            // Remove pipes that are off screen
            if (pipe.x < -this.pipeWidth) {
                pipe.top.remove();
                pipe.bottom.remove();
                this.pipesArray.splice(i, 1);
            }
        }
    }
    
    checkCollisions() {
        // Smaller, more precise bird hitbox
        const birdRect = {
            left: 85,  // More centered on the bird
            right: 115, // Smaller width
            top: this.birdY + 5,  // Slightly smaller height with padding
            bottom: this.birdY + 25
        };
        
        for (const pipe of this.pipesArray) {
            const pipeX = pipe.x;
            
            // Check if bird is in horizontal range of pipe
            if (birdRect.right > pipeX && birdRect.left < pipeX + this.pipeWidth) {
                const topPipeHeight = parseInt(pipe.top.style.height);
                const bottomPipeTop = this.gameArea.offsetHeight - 80 - parseInt(pipe.bottom.style.height);
                
                // Add small padding to pipe collision for more forgiving gameplay
                const collisionPadding = 5;
                
                // Check collision with top pipe
                if (birdRect.top < topPipeHeight - collisionPadding) {
                    this.gameOver = true;
                    this.endGame();
                    return;
                }
                
                // Check collision with bottom pipe
                if (birdRect.bottom > bottomPipeTop + collisionPadding) {
                    this.gameOver = true;
                    this.endGame();
                    return;
                }
            }
        }
    }
    
    endGame() {
        this.gameOver = true;
        clearInterval(this.gameLoop);
        
        // Update high score
        if (this.score > this.highScore) {
            this.highScore = this.score;
            localStorage.setItem('flappyBirdHighScore', this.highScore);
            this.updateHighScore();
        }
        
        // Show game over screen
        this.finalScoreDisplay.textContent = this.score;
        this.finalHighScoreDisplay.textContent = this.highScore;
        this.gameOverScreen.style.display = 'block';
        
        // Add crash animation
        this.bird.classList.add('falling');
    }
    
    resetBirdPosition() {
        this.birdY = 250;
        this.birdVelocity = 0;
        this.bird.style.top = this.birdY + 'px';
        this.bird.classList.remove('falling');
    }
    
    updateScore() {
        this.scoreDisplay.textContent = this.score;
    }
    
    updateHighScore() {
        this.highScoreDisplay.textContent = this.highScore;
    }
}

// Initialize the game when the page loads
document.addEventListener('DOMContentLoaded', () => {
    new FlappyBirdGame();
});