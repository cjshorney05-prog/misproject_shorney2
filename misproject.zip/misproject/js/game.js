document.addEventListener('DOMContentLoaded', () => {
    const canvas = document.getElementById('gameCanvas');
    const ctx = canvas.getContext('2d');
    const gridSize = 20;
    const tileCount = canvas.width / gridSize;
    
    let snake = [];
    let dx = 0;
    let dy = 0;
    let apple = { x: 0, y: 0 };
    let score = 3;
    let highScore = 0;
    let totalScore = parseInt(localStorage.getItem('snakeTotalScore')) || 0;
    let gameOver = false;
    let gameStarted = false;
    let currentDirection = 'none';
    let nextDirection = 'none';
    let directionQueue = [];
    const moveDelay = 10;

    // Audio functionality
    let isMuted = false;
    const backgroundMusic = document.getElementById('backgroundMusic');
    const appleSound = document.getElementById('appleSound');
    const gameOverSound = document.getElementById('gameOverSound');
    const muteButton = document.getElementById('muteButton');

    // Store unlocked items
    let unlockedItems = JSON.parse(localStorage.getItem('snakeUnlockedItems')) || {
        skins: [],
        modes: []
    };

    // Default green snake skin
    const defaultSkin = {
        body: '#32CD32',
        head: '#90EE90',
        border: '#006400'
    };

    // Current selected skin (start with default green)
    let currentSkin = {...defaultSkin};

    // Game speeds for different difficulties
    const speeds = {
        easy: 120,
        medium: 80,
        hard: 50
    };

    let currentSpeed = speeds.medium;

    // Audio control functions
    function initAudio() {
        // Load saved mute state
        const savedMuteState = localStorage.getItem('snakeMuted') === 'true';
        isMuted = savedMuteState;
        updateMuteButton();
        
        // Add mute button event listener
        if (muteButton) {
            muteButton.addEventListener('click', toggleMute);
        }
    }

    function toggleMute() {
        isMuted = !isMuted;
        localStorage.setItem('snakeMuted', isMuted.toString());
        updateMuteButton();
        
        // Update audio playing state
        if (isMuted) {
            stopBackgroundMusic();
        } else if (gameStarted && !gameOver) {
            startBackgroundMusic();
        }
    }

    function updateMuteButton() {
        if (muteButton) {
            if (isMuted) {
                muteButton.textContent = '🔇 Sound Off';
                muteButton.classList.add('muted');
            } else {
                muteButton.textContent = '🔊 Sound On';
                muteButton.classList.remove('muted');
            }
        }
    }

    function playAppleSound() {
        if (!isMuted && appleSound) {
            appleSound.currentTime = 0;
            appleSound.play().catch(e => console.log('Audio play failed:', e));
        }
    }

    function playGameOverSound() {
        if (!isMuted && gameOverSound) {
            gameOverSound.currentTime = 0;
            gameOverSound.play().catch(e => console.log('Audio play failed:', e));
        }
    }

    function startBackgroundMusic() {
        if (!isMuted && backgroundMusic) {
            backgroundMusic.play().catch(e => console.log('Background music play failed:', e));
        }
    }

    function stopBackgroundMusic() {
        if (backgroundMusic) {
            backgroundMusic.pause();
            backgroundMusic.currentTime = 0;
        }
    }

    // Initialize game
    function initGame() {
        const startX = Math.floor(Math.random() * (tileCount - 4)) * gridSize;
        const startY = Math.floor(Math.random() * (tileCount - 4)) * gridSize;
        
        snake = [
            { x: startX + (2 * gridSize), y: startY },
            { x: startX + gridSize, y: startY },
            { x: startX, y: startY }
        ];
        dx = 0;
        dy = 0;
        score = 3;
        gameOver = false;
        gameStarted = false;
        document.getElementById('currentLength').textContent = score;
        document.getElementById('gameOver').classList.add('hidden');
        placeApple();
        draw();
    }

    // Place apple in random position
    function placeApple() {
        apple.x = Math.floor(Math.random() * tileCount) * gridSize;
        apple.y = Math.floor(Math.random() * tileCount) * gridSize;
        
        // Check if apple is on snake
        for (let part of snake) {
            if (part.x === apple.x && part.y === apple.y) {
                placeApple();
                break;
            }
        }
    }

    // Draw everything
    function draw() {
        if (gameOver) return;
        
        // Clear canvas
        ctx.fillStyle = 'white';
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        
        // Don't update position if game hasn't started
        if (!gameStarted) {
            // Just draw the current state
            snake.forEach((part, index) => {
                if (index === 0) {
                    // Draw head with border
                    ctx.fillStyle = currentSkin.head || defaultSkin.head;
                    ctx.fillRect(part.x, part.y, gridSize - 2, gridSize - 2);
                    ctx.strokeStyle = currentSkin.border || defaultSkin.border;
                    ctx.lineWidth = 2;
                    ctx.strokeRect(part.x, part.y, gridSize - 2, gridSize - 2);
                } else {
                    // Draw body
                    ctx.fillStyle = currentSkin.body || defaultSkin.body;
                    ctx.fillRect(part.x, part.y, gridSize - 2, gridSize - 2);
                    // Add outline for white snake body segments
                    if (currentSkin.outline) {
                        ctx.strokeStyle = '#CCCCCC';
                        ctx.lineWidth = 1;
                        ctx.strokeRect(part.x, part.y, gridSize - 2, gridSize - 2);
                    }
                }
            });
            ctx.fillStyle = 'red';
            ctx.fillRect(apple.x, apple.y, gridSize - 2, gridSize - 2);
            requestAnimationFrame(draw);
            return;
        }

        // Draw snake
        snake.forEach((part, index) => {
            if (index === 0) {
                // Draw head with border
                ctx.fillStyle = currentSkin.head || defaultSkin.head;
                ctx.fillRect(part.x, part.y, gridSize - 2, gridSize - 2);
                ctx.strokeStyle = currentSkin.border || defaultSkin.border;
                ctx.lineWidth = 2;
                ctx.strokeRect(part.x, part.y, gridSize - 2, gridSize - 2);
            } else {
                // Draw body
                ctx.fillStyle = currentSkin.body || defaultSkin.body;
                ctx.fillRect(part.x, part.y, gridSize - 2, gridSize - 2);
                // Add outline for white snake body segments
                if (currentSkin.outline) {
                    ctx.strokeStyle = '#CCCCCC';
                    ctx.lineWidth = 1;
                    ctx.strokeRect(part.x, part.y, gridSize - 2, gridSize - 2);
                }
            }
        });
        
        // Draw apple
        ctx.fillStyle = 'red';
        ctx.fillRect(apple.x, apple.y, gridSize - 2, gridSize - 2);
        
        // Process next direction from queue
        if (directionQueue.length > 0 && isValidDirection(currentDirection, directionQueue[0])) {
            const nextDir = directionQueue.shift();
            const velocity = getVelocity(nextDir);
            dx = velocity.dx;
            dy = velocity.dy;
            currentDirection = nextDir;
        }

        // Move snake
        const head = { x: snake[0].x + dx, y: snake[0].y + dy };
        
        // Check for collisions
        if (head.x < 0 || head.x >= canvas.width ||
            head.y < 0 || head.y >= canvas.height ||
            snake.some(part => part.x === head.x && part.y === head.y)) {
            endGame();
            return;
        }

        snake.unshift(head);
        
        // Check if snake ate apple
        if (head.x === apple.x && head.y === apple.y) {
            score += 1;
            document.getElementById('currentLength').textContent = score;
            playAppleSound(); // Play apple sound effect
            placeApple();
        } else {
            snake.pop();
        }
        
        setTimeout(() => requestAnimationFrame(draw), currentSpeed);
    }

    // Direction validation helper
    function isValidDirection(current, next) {
        if (current === 'none') return true;
        
        const opposites = {
            'up': 'down',
            'down': 'up',
            'left': 'right',
            'right': 'left'
        };
        
        return next !== opposites[current];
    }

    // Convert direction to velocity
    function getVelocity(direction) {
        switch(direction) {
            case 'up': return { dx: 0, dy: -gridSize };
            case 'down': return { dx: 0, dy: gridSize };
            case 'left': return { dx: -gridSize, dy: 0 };
            case 'right': return { dx: gridSize, dy: 0 };
            default: return { dx: 0, dy: 0 };
        }
    }

    // Handle keyboard input
    document.addEventListener('keydown', (e) => {
        if (gameOver) return;
        
        // Prevent default arrow key scrolling
        if (["ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight"].includes(e.key)) {
            e.preventDefault();
        }

        let newDirection;
        switch (e.key) {
            case 'ArrowUp':
                newDirection = 'up';
                break;
            case 'ArrowDown':
                newDirection = 'down';
                break;
            case 'ArrowLeft':
                newDirection = 'left';
                break;
            case 'ArrowRight':
                newDirection = 'right';
                break;
            default:
                return;
        }

        // Start game if not started
        if (!gameStarted) {
            gameStarted = true;
            currentDirection = newDirection;
            const velocity = getVelocity(newDirection);
            dx = velocity.dx;
            dy = velocity.dy;
            startBackgroundMusic(); // Start background music when game starts
            return;
        }

        // Queue the new direction if it's different from the last queued direction
        if (directionQueue.length === 0 || directionQueue[directionQueue.length - 1] !== newDirection) {
            if (directionQueue.length < 2) { // Limit queue to 2 moves
                if (isValidDirection(currentDirection, newDirection)) {
                    directionQueue.push(newDirection);
                }
            }
        }
    });

    // End game
    function endGame() {
        gameOver = true;
        stopBackgroundMusic(); // Stop background music
        playGameOverSound(); // Play game over sound
        
        const finalScore = score - 3; // Subtract initial length
        document.getElementById('finalLength').textContent = finalScore;
        document.getElementById('gameOver').classList.remove('hidden');
        
        // Update high score
        if (finalScore > highScore) {
            highScore = finalScore;
            document.getElementById('highScore').textContent = highScore;
        }

        // Update total score
        totalScore += finalScore;
        localStorage.setItem('snakeTotalScore', totalScore);
        document.getElementById('totalScore').textContent = totalScore;

        // Show total score in game over message
        const gameOverText = document.getElementById('gameOver').querySelector('p:first-child');
        gameOverText.textContent = `Game Over! Score: ${finalScore} | Total Score: ${totalScore}`;
    }

    // Handle difficulty changes
    document.getElementById('difficulty').addEventListener('change', (e) => {
        currentSpeed = speeds[e.target.value];
        localStorage.setItem('snakeDifficulty', e.target.value);
    });

    // Load saved difficulty setting
    const savedDifficulty = localStorage.getItem('snakeDifficulty');
    if (savedDifficulty) {
        document.getElementById('difficulty').value = savedDifficulty;
        currentSpeed = speeds[savedDifficulty];
    }
    
    // Restart game
    document.getElementById('restartButton').addEventListener('click', initGame);
    
    // Display high score
    document.getElementById('highScore').textContent = highScore;
    
    // Shop functionality
    function initShop() {
        const shopItems = document.querySelectorAll('.shop-item');
        
        // Mark owned items and update text
        unlockedItems.skins.forEach(skin => {
            const item = document.querySelector(`[data-value="${skin}"]`);
            if (item) {
                item.classList.add('owned');
                const span = item.querySelector('span');
                const colorName = span.textContent.split(' ')[0];
                span.textContent = `${colorName} (unlocked)`;
            }
        });

        // Mark currently selected skin
        const currentSkinName = localStorage.getItem('currentSnakeSkin') || 'default';
        const currentSkinItem = document.querySelector(`[data-value="${currentSkinName}"]`);
        if (currentSkinItem) {
            currentSkinItem.classList.add('selected');
        }

        // Add click handlers
        shopItems.forEach(item => {
            item.addEventListener('click', () => {
                const cost = parseInt(item.dataset.cost);
                const type = item.dataset.type;
                const value = item.dataset.value;

                // Check if already owned
                if (item.classList.contains('owned') || value === 'default') {
                    if (type === 'skin') {
                        // Remove selected class from all items
                        document.querySelectorAll('.shop-item.selected').forEach(item => {
                            item.classList.remove('selected');
                        });
                        // Add selected class to clicked item
                        item.classList.add('selected');
                        // Apply skin
                        applySkin(value);
                    }
                    return;
                }

                // Check if can afford
                if (totalScore >= cost) {
                    // Purchase item
                    totalScore -= cost;
                    localStorage.setItem('snakeTotalScore', totalScore);
                    document.getElementById('totalScore').textContent = totalScore;

                    // Mark as owned and update text
                    item.classList.add('owned');
                    const span = item.querySelector('span');
                    const colorName = span.textContent.split(' ')[0];
                    span.textContent = `${colorName} (unlocked)`;

                    if (type === 'skin') {
                        unlockedItems.skins.push(value);
                        // Remove selected class from all items
                        document.querySelectorAll('.shop-item.selected').forEach(item => {
                            item.classList.remove('selected');
                        });
                        // Add selected class to clicked item
                        item.classList.add('selected');
                        applySkin(value);
                    }
                    localStorage.setItem('snakeUnlockedItems', JSON.stringify(unlockedItems));
                } else {
                    alert('Not enough points!');
                }
            });
        });
    }

    function applySkin(skinName) {
        const skinColors = {
            default: { body: '#32CD32', head: '#90EE90', border: '#006400' },
            red: { body: '#FF0000', head: '#FF4444', border: '#8B0000' },
            yellow: { body: '#FFFF00', head: '#FFFF44', border: '#B8860B' },
            blue: { body: '#0000FF', head: '#4444FF', border: '#00008B' },
            lightblue: { body: '#ADD8E6', head: '#BCE8F6', border: '#4682B4' },
            orange: { body: '#FFA500', head: '#FFB544', border: '#8B4513' },
            pink: { body: '#FFC0CB', head: '#FFD0DB', border: '#FF1493' },
            purple: { body: '#800080', head: '#A020A0', border: '#4B0082' },
            black: { body: '#000000', head: '#333333', border: '#696969' },
            white: { body: '#FFFFFF', head: '#EEEEEE', border: '#A9A9A9', outline: true },
            brown: { body: '#8B4513', head: '#9B5523', border: '#3B1E08' },
            gold: { body: '#FFD700', head: '#FFE744', border: '#DAA520' }
        };

        if (skinColors[skinName]) {
            currentSkin = skinColors[skinName];
            localStorage.setItem('currentSnakeSkin', skinName);
        } else {
            // Reset to default green if skin not found
            currentSkin = defaultSkin;
            localStorage.setItem('currentSnakeSkin', 'default');
        }
    }

    // Initialize audio functionality
    initAudio();

    // Initialize shop
    initShop();

    // Update total score display
    document.getElementById('totalScore').textContent = totalScore;

    // Load saved skin if exists
    const savedSkin = localStorage.getItem('currentSnakeSkin');
    if (savedSkin && (savedSkin === 'default' || unlockedItems.skins.includes(savedSkin))) {
        applySkin(savedSkin);
    }

    // Start the game
    initGame();
});
